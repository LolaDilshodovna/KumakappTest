package com.example.kumakapptest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Donation_item : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_donation_item)
    }
}